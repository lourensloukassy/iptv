import xbmc

url = 'http://alienstreams.fi:7070/staffan.brundin@gmail.com/mZkXfZ8TVW/31469.ts'
xbmc.Player().play(url)